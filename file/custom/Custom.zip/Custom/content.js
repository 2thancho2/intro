let isSelectionMode = false;

// 1. 저장된 데이터 반영 (이미지 무한 루프 + 텍스트 옵저버)
function applyChanges() {
    if (!chrome.runtime?.id) return;
    chrome.storage.local.get(['targetImg', 'changes'], (res) => {
        // 이미지 교체
        if (res.targetImg) {
            document.querySelectorAll('img').forEach(img => {
                if (img.src !== res.targetImg) img.src = res.targetImg;
            });
        }
        // 텍스트/색상 교체
        if (res.changes) {
            res.changes.forEach(item => {
                const elements = document.querySelectorAll(item.selector);
                elements.forEach(el => {
                    if (el.innerText.includes(item.originalText) || el.dataset.changed === "true") {
                        el.innerText = item.text;
                        if (item.color) el.style.color = item.color;
                        el.dataset.changed = "true";
                    }
                });
            });
        }
    });
}

// 0.5초마다 이미지 감시, 텍스트는 옵저버로 감시
setInterval(applyChanges, 500);
const observer = new MutationObserver(applyChanges);
observer.observe(document.body, { childList: true, subtree: true });

// 2. 선택 모드 이벤트
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "startSelection") {
        isSelectionMode = true;
        document.body.style.cursor = "crosshair";
        alert("Select text to change!");
    }
});

document.addEventListener('mouseover', (e) => {
    if (!isSelectionMode) return;
    e.target.style.outline = "2px solid #6B5CE7";
});
document.addEventListener('mouseout', (e) => {
    if (!isSelectionMode) return;
    e.target.style.outline = "";
});

document.addEventListener('click', (e) => {
    if (!isSelectionMode) return;
    e.preventDefault(); e.stopPropagation();

    const originalText = e.target.innerText;
    const newText = prompt("New Text:", originalText);
    
    if (newText !== null) {
        const newColor = prompt("Color (red, #000, etc):", "");
        const selector = getFullSelector(e.target);
        
        chrome.storage.local.get({changes: []}, (data) => {
            data.changes.push({ selector, text: newText, originalText, color: newColor || null });
            chrome.storage.local.set({changes: data.changes}, () => { applyChanges(); });
        });
    }
    isSelectionMode = false;
    document.body.style.cursor = "default";
    e.target.style.outline = "";
}, true);

function getFullSelector(el) {
    const path = [];
    while (el.nodeType === Node.ELEMENT_NODE) {
        let selector = el.nodeName.toLowerCase();
        const index = Array.from(el.parentNode.children).indexOf(el) + 1;
        selector += `:nth-child(${index})`;
        path.unshift(selector);
        el = el.parentNode;
        if (!el || el.tagName === 'HTML') break;
    }
    return path.join(" > ");
}