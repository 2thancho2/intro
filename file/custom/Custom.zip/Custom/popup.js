// --- 탭 전환 로직 ---
const tabImgBtn = document.getElementById('tabImgBtn');
const tabTextBtn = document.getElementById('tabTextBtn');
const imageSection = document.getElementById('imageSection');
const textSection = document.getElementById('textSection');

tabImgBtn.addEventListener('click', () => {
    tabImgBtn.classList.add('active'); tabTextBtn.classList.remove('active');
    imageSection.classList.add('active'); textSection.classList.remove('active');
});

tabTextBtn.addEventListener('click', () => {
    tabTextBtn.classList.add('active'); tabImgBtn.classList.remove('active');
    textSection.classList.add('active'); imageSection.classList.remove('active');
    updateTextList(); // 텍스트 탭 누를 때 목록 갱신
});

// --- 이미지 기능 ---
document.getElementById('saveImgBtn').addEventListener('click', () => {
    const url = document.getElementById('imgUrl').value;
    chrome.storage.local.set({ targetImg: url }, () => { alert('이미지가 설정되었습니다.'); });
});

document.getElementById('resetImgBtn').addEventListener('click', () => {
    chrome.storage.local.set({ targetImg: "" }, () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => chrome.tabs.reload(tabs[0].id));
    });
});

// --- 텍스트 기능 ---
document.getElementById('selectTextBtn').addEventListener('click', () => {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {action: "startSelection"});
        window.close();
    });
});

document.getElementById('resetTextBtn').addEventListener('click', () => {
    if(confirm("모든 텍스트 변경 내역을 지울까요?")) {
        chrome.storage.local.set({ changes: [] }, () => {
            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => chrome.tabs.reload(tabs[0].id));
        });
    }
});

// [핵심] 리스트 갱신 및 개별 삭제 함수
function updateTextList() {
    chrome.storage.local.get({changes: []}, (data) => {
        const listDiv = document.getElementById('list');
        listDiv.innerHTML = '';
        
        if (data.changes.length === 0) {
            listDiv.innerHTML = '<div style="font-size:10px; color:#ccc; text-align:center;">목록이 비어있습니다.</div>';
            return;
        }

        data.changes.forEach((item, index) => {
            const div = document.createElement('div');
            div.className = 'list-item';
            div.innerHTML = `
                <span style="color:${item.color || '#333'}; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:180px;">
                    ${item.text}
                </span>
            `;
            
            // 개별 삭제 버튼 생성
            const delBtn = document.createElement('span');
            delBtn.className = 'delete-item-btn';
            delBtn.innerText = '✕';
            delBtn.addEventListener('click', () => {
                deleteSpecificItem(index);
            });

            div.appendChild(delBtn);
            listDiv.appendChild(div);
        });
    });
}

function deleteSpecificItem(index) {
    chrome.storage.local.get({changes: []}, (data) => {
        const newChanges = data.changes;
        newChanges.splice(index, 1); // 해당 번호만 삭제
        chrome.storage.local.set({changes: newChanges}, () => {
            updateTextList(); // 화면 새로고침
            // 즉시 반영을 위해 페이지 새로고침 권장
            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => chrome.tabs.reload(tabs[0].id));
        });
    });
}

// 처음 팝업 켰을 때 실행
updateTextList();